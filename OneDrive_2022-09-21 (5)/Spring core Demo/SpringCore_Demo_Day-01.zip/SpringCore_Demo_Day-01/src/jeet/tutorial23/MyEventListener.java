package jeet.tutorial23;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;


@Component
public class MyEventListener implements ApplicationListener
{

    @Override
    public void onApplicationEvent(ApplicationEvent event)
    {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("\n\nMyEventListener : "+event.toString() ) ;
    }
    
}
