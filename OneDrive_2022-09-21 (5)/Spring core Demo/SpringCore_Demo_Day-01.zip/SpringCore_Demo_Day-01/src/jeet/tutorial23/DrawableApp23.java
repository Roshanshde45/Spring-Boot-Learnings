//Event Handling concept in Spring
//Example of EventListener by implementing the ApplicationListener e.g. MyEventListener
//Example of Event by extends ApplicationEvent and overriding its default constructor and override toString() method   e.g. DrawEvent

//Event---> EventPublisher----->EventListener
//An Event will be published by Publisher to the EventListener


//Spring Event-1----------------
//                              |
//                              V
//Spring Event-2---> Spring' EventPublisher----->MyEventListener
//                              ^
//                              |
//My DrawEvent-1 ---------------

//NOTE: 
//1) Publisher is actually ApplicationContext
//2) ApplicationContext implements ApplicationEventPublisher
//3) So, publishEvent() method is declared by ApplicationEventPublisher interface and implemented by ApplicationContext.



//AOP

//1) Funtional Oriented Programming
//2) Object Oriented Programming 
//2) Aspect Oriented Programming
        
//        Cross Cutting concern
                



package jeet.tutorial23;

import java.util.Locale;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class DrawableApp23
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring23.xml");
        
        Shape sh = null;
        sh = (Shape) ctx.getBean("circle");
        sh.draw();
        System.out.println("Shape Circle printed.\n\n");
        
        
        
    }

}
