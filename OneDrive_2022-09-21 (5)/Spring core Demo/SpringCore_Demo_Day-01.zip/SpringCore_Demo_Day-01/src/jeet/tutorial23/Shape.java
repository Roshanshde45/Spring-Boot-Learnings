
package jeet.tutorial23;




public interface Shape
{
    public void draw();
}
