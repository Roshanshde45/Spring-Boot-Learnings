package jeet.tutorial23;


import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;


@Component
public class Circle  implements Shape, ApplicationEventPublisherAware
{   
    @Resource
    private Point center;
    
    ApplicationEventPublisher publisher;

    public void draw()
    {   System.out.println("\nCircle  Center Point : " + center);  
    
        DrawEvent drawEvent1 = new DrawEvent(this);
        publisher.publishEvent( drawEvent1 );
    }
    
    public Point getCenter()
    {return center;
    }

    public void setCenter(Point center)
    {this.center = center;
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher)
    {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.publisher = applicationEventPublisher;// Spring provides this Publisher Handler
        //this publisher is actually ApplicationContext
    }

    
}
