package jeet.tutorial04;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp04 
{
	
	public static void main(String[] args) 
        {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring04.xml");
		Triangle triOne = (Triangle)context.getBean("triangleOne");
		triOne.draw();
		Triangle triTwo = (Triangle)context.getBean("triangleTwo");
		triTwo.draw();		
                
	}

}
