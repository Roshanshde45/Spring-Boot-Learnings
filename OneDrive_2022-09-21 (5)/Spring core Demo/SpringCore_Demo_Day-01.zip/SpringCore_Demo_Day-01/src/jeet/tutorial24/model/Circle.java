package jeet.tutorial24.model;

public class Circle
{
    private String name;

    public String getName()
    {   return name;
    }

    public void setName(String name)
    {   this.name = name;
        System.out.println("Circle's setter method : public void setName(String name)");
        throw new RuntimeException();
    }
    
    public String setNameAndReturn(String name)
    {   this.name = name.toUpperCase();
        System.out.println("Circle's setter method: public String setNameAndReturn(String name)");
        return this.name;
    }
}
