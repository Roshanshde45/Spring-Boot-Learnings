package jeet.tutorial24.model;

public class Triangle
{
    private String name;

    public String getName()
    {   return name;
    }

    public void setName(String name)
    {   this.name = name;
    	System.out.println("Triangle's setter method : public void setName(String name)");
    }
    
}
