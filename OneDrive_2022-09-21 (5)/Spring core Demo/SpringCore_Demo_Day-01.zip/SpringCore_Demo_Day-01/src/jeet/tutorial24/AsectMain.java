
package jeet.tutorial24;

import jeet.tutorial24.model.Circle;
import jeet.tutorial24.model.Triangle;
import jeet.tutorial24.service.ShapeService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AsectMain
{
    public static void main(String[] args)
    {
        try
        {
	    	ApplicationContext ctx = new ClassPathXmlApplicationContext("spring24.xml");
	        ShapeService shapeService = (ShapeService)ctx.getBean("shapeService");       
	        
	        System.out.println(shapeService.getTriangle().getName());
	        System.out.println(shapeService.getCircle().getName()); 
	        shapeService.getCircle().setName("My New Circle Name");
	        
	        
	        //This code is for :  public void stringArgumentMethod4(String name, String returnString)
	        shapeService.getCircle().setNameAndReturn("My New Circle Name for advice4");
        }
        catch(Exception e)
        {
        	System.out.println(e);
        
        }

       
    }
    

    
} 


// Note: An "Aspect"(=class) can have multiple "advice"(=methods)

//Step-0: Add the folowing dependency for AspectJ supporting Libraries

/*        <!-- https://mvnrepository.com/artifact/org.springframework/spring-aspects -->
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-aspects</artifactId>
            <version>3.2.0.RELEASE</version>
        </dependency>
*/
//Add the xmlns for aop
//Step-1: Create AspectMain class
//Step-2: Create service.ShapeService class
//Step-3: Create model.Circle and model.Triangle class with refactored "String name" variable
//Step-4: Add bean declaration for Circle, Triangle
//Step-5: Add bean declaration for ShapeService with autowire="byName"

//JoinPoint is the reference point for Pointcut that triggers the execution of Advice.