package jeet.tutorial24.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect
{
    //@Before("execution(public String getName())") //It will work for getName() of all classess.
    //@Before("execution(public String jeet.tutorial24.model.Triangle.getName())")  ////It will work for getName() of on Triangle class.
    @Before("execution(public String get*())") //It will work for all the getters of String typed return value.(It will run the advoice 2 times)
    //@Before("execution(public * get*())")  //It will work for all the getters of any retrun types
    //@Before("execution(public * get*(*))")  //(*)= mandator 1 or more parameters
    //@Before("execution(public * get*(..))")  //(..)= 0 or more parameters
    //@Before("execution(public String jeet.tutorial24.model.*.get*())")  ////It will work for getName() of Circle and Triangle class.    
    //@Before("execution(public * get*())")
    //@Before("allGetters()") // equivalent to @Before("execution(public * get*())")
    public void loggingAdvice()
    {   System.out.println("First Advice Run. Get method called.");
    }
        
    
    /*
    //@Before("execution(public * get*())") // equivalent to @Before("execution(public * get*())")    
    //@Before("allGetters()")
    public void secondAdvice(JoinPoint joinPoint)
    {   System.out.println("Second Advice Run. Get method called.");
        System.out.println(joinPoint.toLongString());
        System.out.println(joinPoint.getTarget() );
    }
    
    
    //@After("args(name)")
    public void stringArgumentMethod(String name)
    {	System.out.println("A method that takes String arguments has been called. The value is : " + name);
    }
    
    
    //Note: for the below code, remove setter method of Circle from spring24.xml
    //@AfterReturning("args(name)")  //It executes when method executed without any exception
    public void stringArgumentMethod2(String name)
    {	System.out.println("A method that takes String arguments has executed successfull without any exception.");
     	System.out.println("The value is : " + name);
    }
    
    
    @AfterThrowing("args(name)")  //It executes when method throws any exception
    public void stringArgumentMethod3(String name)
    {System.out.println("Advice Message: An Exception has been thrown.");
    }
    
    
    @AfterReturning(pointcut="args(name)", returning = "returnString")  //It executes when method executed without any exception
    public void stringArgumentMethod4(String name, String returnString)
    {   System.out.println("Advice: A method that takes String args and returns String executed");
        System.out.println("Input argument: name = " + name);
        System.out.println("Output String: returnString = " + returnString);
    }
    
    
    //NOTE: uncomment the line "throw new RuntimeException();" from setName() of Circle
    //NOTE:  "shapeService.getCircle().setName("My New Circle Name");" will trigger this advice
    @AfterThrowing(pointcut="args(name)", throwing="ex")  //It executes when method executed without any exception
    public void stringArgumentMethod5(String name, RuntimeException ex)
    {System.out.println("Advice  Exception Message: An Exception has been thrown as : \n"+ ex);
    }
    
    
   //NOTE: Comment the line "throw new RuntimeException();" from setName() of Circle    
    @Around("execution(public * get*())")    // For All getters
    public void myAroundAdvice(ProceedingJoinPoint proceedingJoinPoint) // ProceedingJoinPoint is mandatory parameter
    {  try
        {
            //Code for @Before
            System.out.println("@Around: Before Advice");
            proceedingJoinPoint.proceed(); //It actually executes the target method
            //Code for @After
            System.out.println("@Around: After Advice");
        }
        catch (Throwable e)
        {   e.printStackTrace();
        }
        System.out.println("@Around: After Advice");
    }
    */

    
    /*
    @Pointcut("execution(public * get*())") //Pointcut is used to avoid repetition of complext pointcut expression multiple times.
    public void allGetters()  //This is a dummy name
    {
    }
    */
    
    
    //If we have to apply an advice on all the methods within the specific class eg Triangle
    //First method:-    
    //@Pointcut("execution(public * get*())") //To apply 
    //Second method
    //@Pointcut("within(jeet.tutorial24.model.Triangle)")
    //@Pointcut("execution(public * get*())")
    /*public void allCircleMethods()  //This is a dummy name
    {
    }
    */
}