package jeet.tutorial21;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import javax.annotation.Resource;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Controller;

@Controller
public class Circle  implements Shape
{
    private Point center;

    public Point getCenter()
    {return center;
    }

    //@Autowired
    //@Qualifier("circleRelated")   
    //@Resource(name="pt3")   //Used to specify the resource from spring21.xml directly for DI. Uncomment @Autowired and @Qualifier
    @Resource  //It will search a resource with the same name in spring21.xml
    public void setCenter(Point center)
    {this.center = center;
    }
    
    public void draw()
    {   System.out.println("\nCircle  Center Point : " + center);        
    }
    
    @PostConstruct
    public void initializedCircle()
    {   System.out.println("\n\nInit of Circle");
        System.out.println("Init execute after initialization of all member variables of Circle object ");
    }
    
    @PreDestroy
    public void destroyCircle()
    {   System.out.println("\n\ndestroy() of Circle");
        System.out.println("destroy executes before deallocation of Circle object");
    }
}
