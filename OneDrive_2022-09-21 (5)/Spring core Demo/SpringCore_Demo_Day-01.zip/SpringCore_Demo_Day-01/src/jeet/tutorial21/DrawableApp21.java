//  @Autowired Annotation 1)By Type  2)By Name  
//  @Qualifier  
//  @Resource
//  Use of <context:>
//  @PostConstruct
//  @PreDestroy
//  @Component with <context:component-scan> equivalent for  <bean id="circleXML" class="jeet.tutorial21.Circle"></bean>
//  Three types of @Component 1)@Service    2)@Repository   3)@Controller
//  It holds extra information (= purpose ) of the component for MVC architecture.


package jeet.tutorial21;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp21
{
    public static void main(String[] args)
    {
        //ApplicationContext ctx = new ClassPathXmlApplicationContext("spring21.xml");
        AbstractApplicationContext ctx = new ClassPathXmlApplicationContext("spring21.xml"); //Required for shutdown hook
        ctx.registerShutdownHook();//Its tells the spring framework that context has to be close when main() is over
          
        //Shape sh = (Shape) ctx.getBean("circleXML"); //Change this line for @Component annotation of Circle as below
        Shape sh = (Shape) ctx.getBean("circle"); //Component name must be the lower case of Class Name
        sh.draw();
        System.out.println("\nCircle with @Autowired center is printed.\n\n");

    }
}


//NOTE 
//1) First Autowired will search for Autowired by Type
//   if multiple bean ids are available with same type then
//2) Autowire will search for Autowied by Name 
//3) There is Third way i.e. @Qualifier Annotation

