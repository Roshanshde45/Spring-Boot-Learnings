
package jeet.tutorial21;

public interface Shape
{
    public void draw();
}
