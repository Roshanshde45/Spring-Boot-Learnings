package jeet.tutorial05;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring05.xml");
		Triangle tri = (Triangle)ctx.getBean("triangleXML");
		tri.draw();
	}

}
