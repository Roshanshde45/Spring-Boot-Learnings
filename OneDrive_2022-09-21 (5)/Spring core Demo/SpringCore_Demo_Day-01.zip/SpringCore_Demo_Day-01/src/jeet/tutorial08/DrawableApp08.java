package jeet.tutorial08;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp08
{

    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring08.xml");
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }

}
