package jeet.tutorial02;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawingApp02
{
    public static void main(String... args)
    {
        //If spring.xml file is at class path i.e. in src folder
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring02.xml");
        System.out.println("\n\n\n");
        Triangle tri = (Triangle) ctx.getBean("pizza");
        tri.draw();
    }
}










