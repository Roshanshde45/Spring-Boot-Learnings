//Use of PlaceholderConfigurer class of package org.springframework.beans.factory.config.PlaceholderCofigurer
package jeet.tutorial18;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp18
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring18.xml");
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }

}
