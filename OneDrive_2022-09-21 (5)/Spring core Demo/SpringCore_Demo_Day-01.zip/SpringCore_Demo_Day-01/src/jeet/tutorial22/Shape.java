package jeet.tutorial22;

public interface Shape
{
    public void draw();
}
