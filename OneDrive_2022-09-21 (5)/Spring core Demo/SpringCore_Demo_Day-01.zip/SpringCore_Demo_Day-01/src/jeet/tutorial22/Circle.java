package jeet.tutorial22;

import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;

@Controller
public class Circle  implements Shape
{   
    @Resource
    private Point center;

    //It will use Autowired by type because it is  the by default nature of Autowired.
    //We can use it because we have only one bean of this type
    @Autowired     
    private MessageSource messageSource;    //Generate getter & setter
    
    
    public void draw()
    {   
         String str = messageSource.getMessage("greeting", null, "Default Greeting Message", null);
         System.out.println("Message from Circle = " + str);    
         
         System.out.println( messageSource.getMessage("drawing.circle", null, "Default Drawing Message", null) );
         System.out.println(messageSource.getMessage("drawing.point", new Object[]{center.getX(), center.getX()}, "Default Point Message", null));   
    }
    
    public Point getCenter()
    {return center;
    }

    public void setCenter(Point center)
    {this.center = center;
    }

    public void setMessageSource(MessageSource messageSource)
    {   this.messageSource = messageSource;
    }

    public MessageSource getMessageSource()
    {   return messageSource;
    }
}
