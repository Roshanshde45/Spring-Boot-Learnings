//Externalization with the help of MessageResource
package jeet.tutorial22;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class DrawableApp22
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring22.xml");
        String str = ctx.getMessage("greeting", null, "Default Greeting: Hi....!", null);
        System.out.println("Message from DrawableApp22 = " + str);
        
        Shape sh = null;
        sh = (Shape) ctx.getBean("circle");
        sh.draw();
        System.out.println("Shape Circle printed.\n\n");
        
        /*Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
        System.out.println("Circle printed.\n\n");
        
        Circle cir = (Circle) ctx.getBean("circleXML");
        cir.draw();
        System.out.println("Circle printed.\n\n");
        
        Shape sh = null;
        
        //With the usage of Shape Interface
        sh = (Shape) ctx.getBean("triangleXML");
        sh.draw();
        System.out.println("Shape Triangle printed.\n\n");
        Shape sh = null;
        sh = (Shape) ctx.getBean("circleXML");
        sh.draw();
        System.out.println("Shape Circle printed.\n\n");
       */
        
    }

}
