package jeet.tutorial07;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp07 
{

	public static void main(String[] args) 
    {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring07.xml");
		
        System.out.println("\nFirst Triangle Details:-\n");
        Triangle tri1 = (Triangle)ctx.getBean("talias1");
		tri1.draw();
                
        System.out.println("\nSecond Triangle Details:-\n");
        Triangle tri2 = (Triangle)ctx.getBean("talias2");
		tri2.draw();
	}

}
