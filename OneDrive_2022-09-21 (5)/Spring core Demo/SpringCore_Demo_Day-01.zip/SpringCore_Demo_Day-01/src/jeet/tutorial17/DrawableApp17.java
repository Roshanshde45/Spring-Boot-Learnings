package jeet.tutorial17;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp17
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring17.xml");
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }

}
