package jeet.tutorial09;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp09
{
    public static void main(String[] args)
    {   
        //Example of Autowire
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring09.xml");
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }

}
