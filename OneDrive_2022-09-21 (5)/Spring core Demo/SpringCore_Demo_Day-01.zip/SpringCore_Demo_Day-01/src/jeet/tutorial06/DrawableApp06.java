package jeet.tutorial06;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp06 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring06.xml");
		Triangle tri = (Triangle)ctx.getBean("triangleXML");
		tri.draw();
	}

}
