package jeet.tutorial10;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp10
{

    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring10.xml");
        Triangle triObj1 = (Triangle) ctx.getBean("triangleXML1");
        triObj1.draw();
        System.out.println("********************************");
        Triangle triObj2 = (Triangle) ctx.getBean("triangleXML2");
        triObj2.draw();
    }
}
