//Use of PlaceholderConfigurer class of package org.springframework.beans.factory.config.PlaceholderCofigurer
package jeet.tutorial19;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp19
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring19.xml");
        
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
        System.out.println("Circle printed.\n\n");
        
        Circle cir = (Circle) ctx.getBean("circleXML");
        cir.draw();
        System.out.println("Circle printed.\n\n");
        
        Shape sh = null;
        
        //With the usage of Shape Interface
        sh = (Shape) ctx.getBean("triangleXML");
        sh.draw();
        System.out.println("Shape Triangle printed.\n\n");
        
        sh = (Shape) ctx.getBean("circleXML");
        sh.draw();
        System.out.println("Shape Circle printed.\n\n");
        
    }

}
