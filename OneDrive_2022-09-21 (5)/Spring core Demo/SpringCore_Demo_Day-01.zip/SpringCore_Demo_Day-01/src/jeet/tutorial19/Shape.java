
package jeet.tutorial19;


public interface Shape
{
    public void draw();
}
