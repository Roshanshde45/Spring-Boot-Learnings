package jeet.tutorial03;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp03
{


    public static void main(String[] args)
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("spring03.xml");
        Triangle tri = (Triangle) context.getBean("triangle");
        tri.draw();

    }

}
