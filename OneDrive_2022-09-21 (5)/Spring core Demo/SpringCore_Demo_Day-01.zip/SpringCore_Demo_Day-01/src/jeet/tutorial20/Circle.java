package jeet.tutorial20;


import org.springframework.beans.factory.annotation.Required;

public class Circle implements Shape
{
    private Point center;    //To make this variable as a mandatory to initialize, use @Required annotaion with its setter method
   //NOTE: Add a pre-defined BeanPostProcessor in spring.xml file
    public Point getCenter()
    {	return center;
    }

    @Required   
    public void setCenter(Point center)
    {	this.center = center;
    }
    
    public void draw()
    {   System.out.println("\nCircle  Center Point : " + center);
    
    }
}
