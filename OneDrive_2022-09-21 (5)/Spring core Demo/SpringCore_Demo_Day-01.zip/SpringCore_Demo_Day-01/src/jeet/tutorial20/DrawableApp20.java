//Use of Annotation based Spring Bean Container Configuration
//Use of @Required Annotation with the help of
//the BeanPostProcessor : org.springframework.beans.factory.annotation.RequiredAnnotationBeanPostProcesso
package jeet.tutorial20;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp20
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring20.xml");
                        
        Shape sh = (Shape) ctx.getBean("circleXML");
        sh.draw();
        System.out.println("\nCircle with @Required Annotation printed.\n\n");                        
    }
}
