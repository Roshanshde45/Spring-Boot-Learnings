
package jeet.tutorial20;

public interface Shape
{
    public void draw();
}
