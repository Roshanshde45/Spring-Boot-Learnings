package jeet.tutorial16;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp16
{
    public static void main(String[] args)
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring16.xml");
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }

}
