package jeet.tutorial01;

public class Triangle {
	public void draw()
	{
		System.out.println("Triangle Drawn");
	}

}
