package jeet.tutorial01;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class DrawingApp01 
{
    public static void main(String ...args)
	{    //If spring.xml is at root node of the project
         System.out.println("\n\n\n***********1***********************\n");
		 //Old method to create BeanFactory
         //BeanFactory factory = new XmlBeanFactory(new FileSystemResource("spring01.xml"));
         
       //New method to create BeanFactory
         BeanDefinitionRegistry beanDefinitionRegistry = new DefaultListableBeanFactory();
         XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(beanDefinitionRegistry);
         reader.loadBeanDefinitions(new FileSystemResource("spring01.xml") );
         BeanFactory factory = (BeanFactory) reader.getBeanFactory();
         
         
         Triangle tri1 = (Triangle)factory.getBean("triangle");
         tri1.draw();
                
         System.out.println("\n\n\n***********2***********************\n");
                
		 //If spring.xml file is at class path resource i.e. in src/main/resource folder
         ApplicationContext context = new ClassPathXmlApplicationContext("spring01.xml");
         Triangle tri2 =(Triangle) context.getBean("triangle"); 
         tri2.draw();
                
         System.out.println("\n\n\n***********3***********************\n");
	}

}
