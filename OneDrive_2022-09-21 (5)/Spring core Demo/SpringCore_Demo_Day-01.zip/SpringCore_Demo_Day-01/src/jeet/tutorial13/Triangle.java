package jeet.tutorial13;

//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.DisposableBean;
public class Triangle //implements InitializingBean , DisposableBean
{

    private Point pointA;
    private Point pointB;
    private Point pointC;

    public Point getPointA()
    {
        return pointA;
    }

    public void setPointA(Point pointA)
    {
        this.pointA = pointA;
    }

    public Point getPointB()
    {
        return pointB;
    }

    public void setPointB(Point pointB)
    {
        this.pointB = pointB;
    }

    public Point getPointC()
    {
        return pointC;
    }

    public void setPointC(Point pointC)
    {
        this.pointC = pointC;
    }

    public void draw()
    {
        System.out.println("PointA : " + pointA);
        System.out.println("PointB : " + pointB);
        System.out.println("PointC : " + pointC);

//	System.out.println("PointA : ("+getPointA().getX()+","+getPointA().getY()+")");
//	System.out.println("PointB : ("+getPointB().getX()+","+getPointB().getY()+")");
//       System.out.println("PointC : ("+getPointC().getX()+","+getPointC().getY()+")");
    }

    /*@Override
public void afterPropertiesSet() throws Exception {
	System.out.println("InitializBean Init method invoked successfully.");	
  }
@Override
public void destroy() throws Exception {
	System.out.println("DisposableBean destroy method invoked successfully.");
	
}*/
    public void myInit()
    {
        System.out.println("\n\n myInit method of Triangle invoked.\n");
    }

    public void cleanUp()
    {
        System.out.println("\n\ncleanUp method of Triangle invoked\n\n\n");
    }

}
