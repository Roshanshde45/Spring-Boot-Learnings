package jeet.tutorial13;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp13
{
    public static void main(String[] args)
    {
        AbstractApplicationContext ctx = new ClassPathXmlApplicationContext("spring13.xml");
        ctx.registerShutdownHook();//Its tells the spring framework that context has to be close when main() is over
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }
}
