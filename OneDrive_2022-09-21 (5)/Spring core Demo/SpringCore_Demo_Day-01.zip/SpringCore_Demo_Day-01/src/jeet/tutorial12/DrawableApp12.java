package jeet.tutorial12;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawableApp12
{

    public static void main(String[] args)
    {
        AbstractApplicationContext ctx = new ClassPathXmlApplicationContext("spring12.xml");
        ctx.registerShutdownHook();//Its tells the spring framework that context has to be close when main() is over
        Triangle tri = (Triangle) ctx.getBean("triangleXML");
        tri.draw();
    }

}
