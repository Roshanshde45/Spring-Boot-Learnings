package com.jeet;

//NOTE: Download the latest version of Spring framework binaries from https://repo.spring.io/release/org/springframework/spring

public class FirstProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
