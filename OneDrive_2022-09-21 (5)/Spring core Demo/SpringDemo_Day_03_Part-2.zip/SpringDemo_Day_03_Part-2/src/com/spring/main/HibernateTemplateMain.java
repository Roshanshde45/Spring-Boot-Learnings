package com.spring.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.bean.Employee;
import com.spring.dao.EmployeeDao;


public class HibernateTemplateMain 
{
	public static void main(String[] args) 
	{
		ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		EmployeeDao dao = (EmployeeDao) ctx.getBean("empHibTemplatedao");
		
		Employee e1=new Employee(131, "Jeet", "BA");
		Employee e2=new Employee(132, "Alice", "QA");
		dao.save(e1);
		dao.save(e2);			
		System.out.println("All Employee data Saved successfully\n\n");
		
		List<Employee>  elist = dao.getAll();
		System.out.println(elist);		
	}
}
