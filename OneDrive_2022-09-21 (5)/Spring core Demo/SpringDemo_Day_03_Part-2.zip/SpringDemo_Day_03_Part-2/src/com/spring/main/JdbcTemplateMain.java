package com.spring.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.bean.Employee;
import com.spring.dao.EmployeeDao;

public class JdbcTemplateMain 
{

	public static void main(String[] args) 
	{  	ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		EmployeeDao edao= (EmployeeDao) ctx.getBean("emptemplatedao");
		
		Employee emp=new Employee(128,"Mohit", "Tester");
		edao.save(emp);
		
		
		List<Employee>  elist = edao.getAll();
		System.out.println("Eid\t Ename \t Role ");
		for(Employee e:elist)
		{
			System.out.println(e.getId()+" "+e.getName()+" "+e.getRole());
		}

	}

}
