package com.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;
import com.spring.bean.Employee;

public class EmployeeHibernateDaoImpl implements EmployeeDao
{
	HibernateTemplate  template;

	public HibernateTemplate getTemplate() 
	{ 	return template;
	}

	public void setTemplate(HibernateTemplate template) 
	{ 	this.template = template;
	}

	@Override
	public void save(Employee emp) 
	{ 	//template.save(emp);			
		Session session = this.template.getSessionFactory().openSession();
		session.save(emp); 
		session.flush();		 
	    System.out.println("Employee Object Saved in database successfully.");
	}

	@Override
	public List<Employee> getAll() 
	{ 	List<Employee>  elist= new ArrayList<Employee>();
		elist=template.loadAll(Employee.class);
	    return elist;
	}

}
