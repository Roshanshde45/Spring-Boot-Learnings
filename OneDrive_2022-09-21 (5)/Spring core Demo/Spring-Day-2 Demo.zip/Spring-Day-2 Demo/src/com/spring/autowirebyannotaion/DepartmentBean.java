package com.spring.autowirebyannotaion;

public class DepartmentBean {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}



/*
1) com.spring.collection
   Compnay
   CollectionMain
   
2) com.spring.objcollist
   Department
   Company
   ObjListMain
   
3) com.spring.beanscope
   Customer
   ScopeMain
   
4) com.spring.beanlifecyclebyattribute;
   Customer 
   MainApp
   
5) com.spring.beanlifecyclebyannotaton;
   Customer 
   MainApp
     
6) com.spring.autowirebynameandbytpe
   DepartmentBean
   EmployeeBean
   MainApp
  
7) com.spring.autowirebyannotaion
   DepartmentBean
   EmployeeBean
   MainApp
   
*/