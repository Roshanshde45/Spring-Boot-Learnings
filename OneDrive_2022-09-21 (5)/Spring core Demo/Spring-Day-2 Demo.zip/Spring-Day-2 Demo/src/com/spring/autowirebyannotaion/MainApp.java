package com.spring.autowirebyannotaion;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp
{

	public static void main(String[] args) 
	{
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/autowirebyannotaion/spring.xml");
		EmployeeBean e = (EmployeeBean) ctx.getBean("emp");
		e.print();

	}

}
