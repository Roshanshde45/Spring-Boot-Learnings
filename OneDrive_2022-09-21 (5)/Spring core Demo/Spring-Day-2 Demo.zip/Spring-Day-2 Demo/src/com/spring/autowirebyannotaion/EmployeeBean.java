package com.spring.autowirebyannotaion;

import org.springframework.beans.factory.annotation.Autowired;
public class EmployeeBean 
{
	private String fullName ;
	
	@Autowired(required=false)
	private DepartmentBean  dbean;
	
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public DepartmentBean getDbean() {
		return dbean;
	}
	public void setDbean(DepartmentBean dbean) {
		this.dbean = dbean;
	}
	public void print(){
		System.out.println("Name "+fullName+" Dep Name "+dbean.getName());
	}
	

}
