package com.spring.beanscope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopeMain 
{
	public static void main(String[] args) 
	{
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/beanscope/spring.xml");
		
		
		Customer obj1 = (Customer) ctx.getBean("custSing");
		obj1.setCustId(101);
		obj1.setCustName("Jeetendra");
		
		// Here i requsted same bean from conatiner
		Customer obj2 = (Customer) ctx.getBean("custSing");
		System.out.println("\n\nObject info having Singleton Scope");
		
		System.out.println("Info of Obj1 = " + obj1.getCustId() + " " + obj1.getCustName());
		System.out.println("Info of Obj2 = " + obj2.getCustId() + " " + obj2.getCustName());

		
		
		
		
		Customer obj3 = (Customer) ctx.getBean("custPro");
		obj3.setCustId(102);
		obj3.setCustName("Priti");
		
		// Here i reqused same bean from conatiner
		Customer obj4 = (Customer) ctx.getBean("custPro");
		
		
		System.out.println("\n\nObject info having Prototype Scope");
		System.out.println("Info of Obj3 = " + obj3.getCustId() + " " + obj3.getCustName());
		System.out.println("Info of Obj4 = " + obj4.getCustId() + " " + obj4.getCustName());

	}

}
