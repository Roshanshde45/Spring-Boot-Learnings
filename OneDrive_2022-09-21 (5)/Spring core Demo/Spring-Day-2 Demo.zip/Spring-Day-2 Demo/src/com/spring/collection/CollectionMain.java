package com.spring.collection;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CollectionMain 
{
	public static void main(String[] args) 
	{ 
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		Compnay c = (Compnay) ctx.getBean("momos");
		System.out.println("Compnay Name" + c.getName());
		System.out.println("Bu's Name" + c.getBu());
		System.out.println("Account Name" + c.getAccounts());
		System.out.println("Infogain at Name" + c.getLocations());			
	}
}
