package com.spring.collection;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Compnay 
{
	private String name;
	private List<String> bu;
	private Set<String>  accounts;
	private Map<String,String> locations;
	
	public String getName() 
	{ 	return name;
	}
	public void setName(String name) 
	{ 	this.name = name;
	}
	public List<String> getBu() 
	{ 	return bu;
	}
	public void setBu(List<String> bu) 
	{ 	this.bu = bu;
	}
	public Set<String> getAccounts() 
	{ 	return accounts;
	}
	public void setAccounts(Set<String> accounts) 
	{ 	this.accounts = accounts;
	}
	public Map<String, String> getLocations() 
	{ 	return locations;
	}
	public void setLocations(Map<String, String> locations) 
	{ 	this.locations = locations;
	}
}
