package com.spring.beanlifecyclebyattribute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp 
{
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/beanlifecyclebyattribute/spring.xml");
		Customer cust = (Customer) ctx.getBean("cust");
	    cust.print();
	    ctx.close();
	    //cust.destroy();
	    cust.print();
	}
}
