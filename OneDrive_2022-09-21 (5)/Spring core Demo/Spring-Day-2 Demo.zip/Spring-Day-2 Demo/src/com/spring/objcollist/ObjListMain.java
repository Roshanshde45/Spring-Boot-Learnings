package com.spring.objcollist;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ObjListMain 
{
	public static void main(String[] args) 
	{ 	
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/objcollist/spring.xml");
		Company c = (Company) ctx.getBean("pizza");
		c.print();
	}
}
