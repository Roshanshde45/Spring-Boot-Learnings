package com.spring.objcollist;

import java.util.List;

public class Company 
{
	private String name;
	private List<Department> dept;
	
	public String getName() 
	{ 	return name;
	}
	public void setName(String name) 
	{ 	this.name = name;
	}
	public List<Department> getDept() 
	{ 	return dept;
	}
	public void setDept(List<Department> dept) 
	{ 	this.dept = dept;
	}
	
	
	// Need to declare a method print will display cname  and the dept names
	// Load spring.xml   and call this print method
	
	public void print()
	{ 	
		System.out.println("Compnay Name " +name);	
		
		for(Department d:dept)
		{ 	System.out.println("Dept Name " +d.getName());
		}
	}
			
}
	
	
	
	


