package com.spring.beanlifecyclebyannotaton;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Customer  
{
	private int custId;
	private String custName;
	
	@PostConstruct
	public void init ()
	{ 	System.out.println("Inside init method Object is inlized ");
		setCustName("Rohit");
	}
	
	@PreDestroy
	public void destroy()
    { 	System.out.println("Object is going to be uninlized ");
		custId=0;
		custName=null;
		System.out.println("Object is  uninlized ");
	}
	
	public void print()
	{ 	System.out.println("Cust Id "+custId+" Name "+ custName);
	}
	
	
	public int getCustId() 
	{ 	return custId;
	}
	public void setCustId(int custId) 
	{ 	this.custId = custId;
	}
	public String getCustName() 
	{ 	return custName;
	}
	public void setCustName(String custName) 
	{ 	this.custName = custName;
	}
}
