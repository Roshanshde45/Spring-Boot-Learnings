package com.spring.autowirebynameandbytpe;

public class EmployeeBean 
{	
	private String 	fullName ;
	private DepartmentBean  dbean;
	
	
	public void print()
	{ 	System.out.println("Name="+fullName+"   Dep Name="+dbean.getName());
	}
	
	public String getFullName() 
	{ 	return fullName;
	}
	public void setFullName(String fullName) 
	{ 	this.fullName = fullName;
	}
	public DepartmentBean getDbean() 
	{ 	return dbean;
	}
	public void setDbean(DepartmentBean dbean) 
	{ 	this.dbean = dbean;
	}
}
