package com.spring.bean;
import java.util.Scanner;

public class Customer 
{
	private Integer custId;
	private String custName;
	private float  orderAmt;
	
	public Customer()
	{		
	}
		
	public Customer(Integer custId, String custName, float orderAmt)
	{ 	super();
		this.custId = custId;
		this.custName = custName;
		this.orderAmt = orderAmt;
	}
	public void print()
	{ 	System.out.println("\nCust Id  = " + custId   + 
						   "\nName     = " + custName + 
						   "\nOrder Amt= " + orderAmt   );
	}	
	
	
	
	public Integer getCustId() 
	{ 	return custId;
	}
	public void setCustId(Integer custId) 
	{ 	this.custId = custId;
	}
	public String getCustName() 
	{ 	return custName;
	}
	public void setCustName(String custName) 
	{ 	this.custName = custName;
	}
	public float getOrderAmt() 
	{ 	return orderAmt;
	}
	public void setOrderAmt(float orderAmt) 
	{ 	this.orderAmt = orderAmt;
	}
	
		
	public static Customer createBean()
	{ 	Scanner sc= new Scanner(System.in);
		System.out.println("Enter Cust Name ");
		String nm= sc.nextLine();
				
		System.out.println("Enter Cust Id ");
		int cid= sc.nextInt();
		
		System.out.println("Enter Order amt ");
		Float oadmt= sc.nextFloat();
		
		return new Customer(cid, nm, oadmt);				
	}
	
}
