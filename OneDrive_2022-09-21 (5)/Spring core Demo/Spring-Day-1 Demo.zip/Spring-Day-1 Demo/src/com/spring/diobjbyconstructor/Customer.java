package com.spring.diobjbyconstructor;

public class Customer 
{
	private int custId;      // Primitive
	private String custName;
	private Address add;     // Object refrence
	
	
	public Customer()
	{
	}
		
	public Customer(int custId, String custName, Address add) 
	{ 	super();
		this.custId = custId;
		this.custName = custName;
		this.add = add;
	}

	public int getCustId() 
	{ 	return custId;
	}
	public void setCustId(int custId) 
	{ 	this.custId = custId;
	}
	public String getCustName() 
	{ 	return custName;
	}
	public void setCustName(String custName) 
	{ 	this.custName = custName;
	}
	public Address getAdd() 
	{ 	return add;
	}
	public void setAdd(Address add) 
	{ 	this.add = add;
	}
}
