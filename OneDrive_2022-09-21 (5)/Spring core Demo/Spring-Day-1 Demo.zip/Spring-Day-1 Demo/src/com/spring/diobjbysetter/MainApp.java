package com.spring.diobjbysetter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp 
{
	public static void main(String[] args) 
	{	
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/spring/diobjbysetter/spring.xml");
		Customer cust = (Customer) ctx.getBean("cust");
		
		System.out.println("\nCust Id : " + cust.getCustId()   +
							"\nName   : " + cust.getCustName() + 
							"\nCity   : " + cust.getAdd().getCity() );
	}
}
