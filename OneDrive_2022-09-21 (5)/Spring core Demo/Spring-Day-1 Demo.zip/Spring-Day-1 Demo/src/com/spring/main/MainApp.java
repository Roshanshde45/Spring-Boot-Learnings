package com.spring.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.spring.bean.Customer;

public class MainApp 
{
	public static void main(String[] args) 
	{
		// Reqirement:- Need to create the object of Cusomer initize it properties
		// and dispay the info

		Customer  cust = new Customer();				
		cust.setCustId(101);
		cust.setCustName("Jeetendra");
		cust.setOrderAmt(3000.78f);
		cust.print();
		
		Resource  res =  new ClassPathResource("spring.xml");
		BeanFactory factoy = new XmlBeanFactory(res);
			   
		Customer  cust1= (Customer)factoy.getBean("cust");
		System.out.println("Cust-1 Id "   +  cust1.getCustId()   +
							" Name "    +  cust1.getCustName() +
							" Order Amt "+  cust1.getOrderAmt()    );

		Customer cust2= (Customer)factoy.getBean("custobj");
		System.out.println("Cust-2 Id "   +  cust2.getCustId()   +
							" Name "    +  cust2.getCustName() +
							" Order Amt "+  cust2.getOrderAmt()    );
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		Customer cust3 = (Customer) ctx.getBean("custobj1");
		cust3.print();
	}//end of main() method
}
