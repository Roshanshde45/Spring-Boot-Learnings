package com.spring.service;

public interface SimpleService 
{
	public void checkName();
	
	public  void printNameId();
	
	public String reteurnValue(String msg);

}
