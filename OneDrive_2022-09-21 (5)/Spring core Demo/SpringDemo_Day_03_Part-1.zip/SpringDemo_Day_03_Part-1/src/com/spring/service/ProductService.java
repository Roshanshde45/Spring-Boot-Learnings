package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.model.Computer;
import com.spring.model.Printer;
public class ProductService 
{
	@Autowired
	private Printer printer;
	
	@Autowired
	private Computer  computer;
	
	public Printer getPrinter() 
	{ 	System.out.println("GetPrinter from ProdService");
		return printer;
	}
	public void setPrinter(Printer printer) 
	{ 	this.printer = printer;
	}
	public Computer getComputer() 
	{ 	System.out.println("GetComputer from ProdService");
		return computer;
	}
	public void setComputer(Computer computer) 
	{ 	this.computer = computer;
	}
}
