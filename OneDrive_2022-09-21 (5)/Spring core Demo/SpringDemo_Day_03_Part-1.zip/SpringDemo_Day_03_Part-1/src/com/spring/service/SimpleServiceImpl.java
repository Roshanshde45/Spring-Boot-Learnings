package com.spring.service;

public class SimpleServiceImpl implements SimpleService 
{
	private String name;
	private Integer id;	
    
	@Override
	public void checkName() 
	{ 	if(name.length()<5)
		{ 	throw   new IllegalArgumentException();
		}
		System.out.println("Inside checkName() method of SimpleService Class");
	}

	@Override
	public void printNameId() 
	{ 	System.out.println("EID="+id+"   Name="+name);		
	}

	@Override
	public String reteurnValue(String msg)
	{ 	return "Hello " + msg;
	}

	public String getName() 
    { 	return name;
    }
	public void setName(String name) 
	{ 	this.name = name;
	}
	public Integer getId() 
	{ 	return id;
	}
	public void setId(Integer id) 
	{ 	this.id = id;
	}

}
