package com.spring.model;

public class Computer 
{
	private String name;
	
	//JoinPoint
	public String getName() 
	{ 	return name;
	}

	public void setName(String name) 
	{ 	this.name = name;
	}
}
