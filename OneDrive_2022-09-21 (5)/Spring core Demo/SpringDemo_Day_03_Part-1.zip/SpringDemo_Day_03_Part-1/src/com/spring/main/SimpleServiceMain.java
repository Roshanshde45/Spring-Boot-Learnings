package com.spring.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.service.SimpleService;
public class SimpleServiceMain 
{
public static void main(String[] args) 
{
		ApplicationContext   ctx = new ClassPathXmlApplicationContext("spring.xml");
		SimpleService   service = (SimpleService)ctx.getBean("simpleservice");
		
		try
		{	service.checkName();
		}
		catch(Exception e)
		{			
		}
		
		//service.printNameId();
		//service.reteurnValue("Good After Noon");

	}

}
