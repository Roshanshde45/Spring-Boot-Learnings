package com.spring.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.model.Computer;
import com.spring.model.Printer;
import com.spring.service.ProductService;

public class ProductMain 
{
	public static void main(String[] args) 
	{ 	
		ApplicationContext   ctx = new ClassPathXmlApplicationContext("spring.xml");
		ProductService  ps= (ProductService) ctx.getBean("prodService");
	
		Computer comp=  ps.getComputer();
		System.out.println(comp.getName());
	
		Printer p= ps.getPrinter();
		System.out.println(p.getName());
	}
}
