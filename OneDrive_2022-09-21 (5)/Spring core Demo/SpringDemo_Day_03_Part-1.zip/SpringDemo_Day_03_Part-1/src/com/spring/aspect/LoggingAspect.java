package com.spring.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
// Aspect Class
@Aspect
public class LoggingAspect 
{
	/*
	@Before("execution(public String getName())")
	public void loggingAspect()	// Advice Method
	{ 	System.out.println("Do Before Advice Method is called...");
	} 
	*/
	
	
	/*
	@Before("execution(public String com.spring.model.Computer.getName())")
	public void loggingAspect()	// Advice Method
	{ 	System.out.println("Do Before Advice Method is called...");
	}
	*/
	
	
	/*
	@Before("execution(public * get*())")
	public void loggingAspect()	// Advice Method
	{ 	System.out.println("Do Before Advice Method is called...");
	}
	*/
	
	
	@Before("execution(* get*())")
	public void loggingAspect()	// Advice Method
	{
		System.out.println("Do Before Advice Method is called...");
	}

}
