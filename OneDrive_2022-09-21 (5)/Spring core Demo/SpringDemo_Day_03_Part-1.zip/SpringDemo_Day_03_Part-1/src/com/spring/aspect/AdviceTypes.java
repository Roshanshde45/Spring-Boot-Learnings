package com.spring.aspect;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AdviceTypes 
{	
	@Pointcut("execution(* com.spring.service.SimpleService.checkName(..))")
	public void myPointCut()
	{		
	}
	
	//@After("execution(* com.spring.service.SimpleService.checkName(..))")
	@After("myPointCut()")
	public void doAfter(JoinPoint jp)
	{ 	System.out.println("Aspect DoAfter () advice is running...");
		System.out.println("Currently Adviced Join Point Method  is : "+jp.getSignature().getName());
		System.out.println("Target Class : "+jp.getTarget().getClass().getName());
		
	}
	
	@AfterThrowing("myPointCut()")
	public void afterThrowing()
	{ 	System.out.println("***Exception : Name should be mor than Five chars");					
	}
	
	@Around("execution(* com.spring.service.SimpleService.printNameId(..))")
	public void   doAround(ProceedingJoinPoint pjp) throws Throwable
	{ 	System.out.println("***Start Printing Employee Info*****");
		pjp.proceed();
		System.out.println("***Stop Printing Employee Info*****");
	}
	
	
	@AfterReturning(pointcut="execution(* com.spring.service.SimpleService.reteurnValue(..))",returning="rtval")
	public void   doAfterReturning(String rtval) throws Throwable
	{ 	System.out.println("***Reteruned Value inside Advice Method..."+rtval);						
	}
	
}


/*

com.spring.model;
   1) Computer
   2) Printer

com.spring.service
   3) ProductService
   5) SimpleServiceImpl----->6)SimpleService

com.spring.main
   4) ProductMain
   7) SimpleServiceMain 
    
com.spring.aspect
  8) LoggingAspect  
  9) AdviceTypes
  
*/



   

