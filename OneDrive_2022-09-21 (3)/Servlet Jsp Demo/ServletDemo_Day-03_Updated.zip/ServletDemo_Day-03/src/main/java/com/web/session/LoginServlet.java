package com.web.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet 
{	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		final String uidInDB="jeet";
		final String pwdInDB="admin1234";
		
		PrintWriter out= response.getWriter();
		String user  = request.getParameter("t1_user");
		String  pwd = request.getParameter("t2_pwd");
		
		if( uidInDB.equalsIgnoreCase(user) && pwdInDB.equals(pwd)  )
		{
			HttpSession s = request.getSession();			
			s.setAttribute("user", user);
			response.sendRedirect("loginsuccess.jsp");
		}
		else
		{
			RequestDispatcher rd= request.getRequestDispatcher("sessionlogin.jsp");
			out.println("<font color=red> Eiter user or pwd is wrong </font>");			
			rd.include(request, response);
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{		doGet(request, response);
	}

}
