package com.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.web.connection.ConnectionProvider;

public class SearchServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		PrintWriter out=response.getWriter();
		out.println("<h1>Without DAO Architecture.</h1>");
		
		String empid= request.getParameter("empid");
		
		Connection con=null;
		String query= "select * from employees_Info where employee_id =?";
		try
		{
			con= ConnectionProvider.getConnection();
			PreparedStatement ps= con.prepareStatement(query);
			ps.setInt(1, Integer.parseInt(empid));
			
			ResultSet rs= ps.executeQuery();
			
			while(rs.next())
			{	
				out.println("<br> EmployeeID : " + rs.getInt(1) );
				out.println("<br> Empl Name : "  + rs.getString(2) );
				out.println("<br> Emp Email : "  + rs.getString(3) );
				out.println("<br> Country   : "  + rs.getString(4) );
			}			
		}
		catch(Exception e)
		{	e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
