package com.web.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.web.connection.ConnectionProvider;
import com.web.connection.MyDBConnection;
import com.web.model.Employee;

public class EmployeeDao 
{
	public static int save(Employee e)
	{  
	        int status=0;  
	        try
	        {  
	            Connection con=new MyDBConnection().openConnection();
	        	
	        	//Connection con= ConnectionProvider.getConnection()  ;
	            PreparedStatement ps=con.prepareStatement(  
	            		"insert into employees_Info values (?,?,?,?)");  
	            ps.setInt(1, e.getId())   ;
	            ps.setString(2,e.getName());  
	            ps.setString(3,e.getEmail());  
	            ps.setString(4,e.getCountry());  
	            
	            status=ps.executeUpdate();                
	            con.close();  
	        }
	        catch(Exception ex)
	        {	ex.printStackTrace();
	        }  
	          
	        return status;  
	        
	}//end of save() method  
	
	public static List<Employee> getAllEmployees()
	{  
		List<Employee> list=new ArrayList<Employee>();  
		          
		try
		{  
			Connection con=new MyDBConnection().openConnection()  ;
			//Connection con= ConnectionProvider.getConnection()  ;
		    PreparedStatement ps=con.prepareStatement("select * from employees_Info");  
		    ResultSet rs=ps.executeQuery();  
		    while(rs.next())
		    {  
		    	Employee e=new Employee();  
		        e.setId(rs.getInt("EMPLOYEE_ID"));  
		        e.setName(rs.getString("NAME"));  
		        e.setEmail(rs.getString("EMAIL"));  
		        e.setCountry(rs.getString("COUNTRY"));  
		        list.add(e);  
		    }  
		    con.close();  
		}
		catch(Exception e)
		{	System.out.println("Some Exception : " + e);
		}  
		return list;  
	}//end of getAllEmployees() method  
		
	public static Employee  searchByempId(int empid)
	{   Employee e = null;	
		try
		{  
			Connection con=new MyDBConnection().openConnection()  ;
			//Connection con= ConnectionProvider.getConnection()  ;
		    PreparedStatement ps=con.prepareStatement("select * from employees_Info where employee_id =?");  
		    ps.setInt(1, empid);
		    
		    ResultSet rs=ps.executeQuery();  
		    
		    if(rs.next())
		    {  
		    	e = new Employee();
		        e.setId(rs.getInt("EMPLOYEE_ID"));  
		        e.setName(rs.getString("NAME"));  
		        e.setEmail(rs.getString("EMAIL"));  
		        e.setCountry(rs.getString("COUNTRY"));  
		    }  
		    con.close();  
		}
		catch(Exception ex)
		{	System.out.println("Some Exception : " + ex);
		} 
		return e;
	}

}
