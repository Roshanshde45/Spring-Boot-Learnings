package com.web.listener;

public class Employee 
{
	private String name;
	private String add;	
	
	public Employee(String name, String add) 
	{
		super();
		this.name = name;
		this.add = add;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	
	
}
