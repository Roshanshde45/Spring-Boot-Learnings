package com.web.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CalculatorServlet extends HttpServlet 
{
		
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	
		PrintWriter out = response.getWriter();
		try
		{
			int num1 = 0;			
			int num2 = 0; 

			num1 = Integer.parseInt(request.getParameter("t1"));
			num2 = Integer.parseInt(request.getParameter("t2"));
			int res = num1  / num2 ;
			
			out.println("Division Result from Server = " + res);
		}
		catch(NumberFormatException nfex)
		{	response.sendRedirect("index.jsp?MSG=Invalid values in textbox.");
		}
		catch(Exception e)
		{   response.sendError(403, "You are not authorized for Result.");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
