package com.web.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ShopingCart extends HttpServlet 
{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String str1=request.getParameter("item");
		String str2=request.getParameter("qty");
		
		String str3=request.getParameter("add");
		String str4=request.getParameter("list");
		
		PrintWriter out=response.getWriter();
		if(str3 != null)
		{
			Cookie c1=new Cookie(str1, str2);
			//c1.setMaxAge(30*24*60*60);
			
			response.addCookie(c1);
			response.sendRedirect("cart.jsp");
		}
		else if(str4!=null)
		{
			Cookie c[]=request.getCookies();
			for(int i=0;i<c.length;i++)
			{
				out.print("<b>"+c[i].getName()+" ==== "+c[i].getValue()+"</b><br/>");
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
