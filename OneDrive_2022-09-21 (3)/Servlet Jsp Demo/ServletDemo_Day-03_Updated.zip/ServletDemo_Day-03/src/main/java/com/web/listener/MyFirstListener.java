package com.web.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class MyFirstListener implements ServletContextListener 
{

	public void contextInitialized(ServletContextEvent arg0)  
    { 
        System.out.println("Context uploaded in Tomcat server.");
       
        ServletContext  ctx= arg0.getServletContext();
        
		Employee eobj1=new Employee("Jeet","Noida");
		Employee eobj2=new Employee("James","FBD");
		
		ctx.setAttribute("obj1", eobj1);
		ctx.setAttribute("obj2", eobj2);
		System.out.println("Data added to Servlet Context");
       
    }
	
    public void contextDestroyed(ServletContextEvent arg0)  
    { 
    	 System.out.println("Context removed from Tomcat server.");
    }
	
}
