package com.web.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.dao.EmployeeDao;
import com.web.model.Employee;

/*
Note-1: Configure context.xml :-
-----------------------------
	To declare a JNDI DataSource for the Oracle 11g XE database, create a Resource XML element with the following content:
	    <Resource
			    name="jdbc/OracleDB"
			    auth="Container"
			    type="javax.sql.DataSource"
			    maxActive="100"
			    maxIdle="30"
			    maxWait="10000"
			    driverClassName="oracle.jdbc.OracleDriver"
			    url="jdbc:oracle:thin:@localhost:1521:xe"
			    username="oracleuser2"
			    password="password" />
		
	Add this element inside the root element <Context> in a context.xml file of Tomcat Server.
	
		    
Note-2: Configure web.xml
-------------------------
	Add the following declaration into the web.xml file:
	<resource-ref>
	    <description>DB Connection</description>
	    <res-ref-name>jdbc/OracleDB</res-ref-name>
	    <res-type>javax.sql.DataSource</res-type>
	    <res-auth>Container</res-auth>
  	</resource-ref>
  	
  	This is necessary in order to make the JNDI DataSource available to
    the application under the specified namespace jdbc/OracleDB.

Note-3: Create table Employee in Oracle Database as follows:-

create table  employees_Info
(
	employee_id  int primary key,
	name    varchar2(30),
	email   varchar2(30),
	country varchar2(30)
);

 */


public class AddEmployee extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();  
	    int id  = Integer.parseInt(request.getParameter("id"));
	    String name   = request.getParameter("name");  
	    String email  = request.getParameter("email");  
	    String country= request.getParameter("country");
	    
	    Employee e=new Employee();  
	    e.setId(id);
	    e.setName(name);  
	    e.setEmail(email);  
	    e.setCountry(country);
	    
	    int status=EmployeeDao.save(e); 
	    
	    if(status>0)
	    {   out.print("<h3>Record saved successfully!</h3>");  
	        request.getRequestDispatcher("emp.html").include(request, response);  
	        
	    }
	    else
	    {   out.println("Sorry! unable to save record");  
	    }  
	      
	    out.close();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
