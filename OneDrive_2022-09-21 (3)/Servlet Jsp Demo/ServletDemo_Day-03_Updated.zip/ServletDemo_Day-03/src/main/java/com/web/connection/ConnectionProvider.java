package com.web.connection;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class ConnectionProvider 
{
	public static Connection getConnection() 
	{
		Connection con = null;
		try 
		{	Class.forName("oracle.jdbc.OracleDriver");			
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "oracleuser2", "password");
		} 
		catch (ClassNotFoundException | SQLException e) 
		{	System.out.println("Exception in Connection : " + e);
		}
		
		/* returns connection object */
		return con;
	}
	
}//end of ConnectionProvider
