package com.web.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class AuthFilter implements Filter 
{
	
	public void init(FilterConfig fConfig) throws ServletException 
	{
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		System.out.println("Inside Auth filter");
		PrintWriter out= response.getWriter();
		
		String pwd= request.getParameter("password");
		
		if(pwd.equalsIgnoreCase("admin1234"))
		{
			// pass the request along the filter chain
			chain.doFilter(request, response);
		}
		else
		{
			RequestDispatcher rd= request.getRequestDispatcher("index.jsp");
			out.println("<font color=red> Wrong Password  </font>");
			rd.include(request, response);
		}		
	
	}


	public void destroy() 
	{
	}
}
