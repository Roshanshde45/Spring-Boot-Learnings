package com.pack02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EmpServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try( PrintWriter out= response.getWriter() )
		{  
			    out.println("<h1> Welcome to EmpServlet </h1>");
			  
				
				int eid= Integer.parseInt(request.getParameter("eid"));
				
				String name  = request.getParameter("ename");
				
				String gen   = request.getParameter("gen");
				
				String quil[]= request.getParameterValues("quil");
				
				String add   = request.getParameter("add");
				
				String country = request.getParameter("country");
				
				out.println("<br><br>Employee Deatils <br>");
				out.println("<br/><b>Emp id</b> "+eid);
				out.println("<br/><b>Emp Name</b> "+name);
				out.println("<br/><b>Gender</b> " +gen);
				out.println("<br/><b>Quil</b> ");
				
				for(String q:quil)
				{
					out.println(q+" ");
				}
				
				out.println("<br/><b>Address</b> "+add);
				out.println("<br/><b>Country</b> "+country);
				
				//---------------------------------------------------------
				
				out.println("<table align='center' border=1>");
				out.println("<tr>");
				out.println("<td><b>Emp id</b></td> <td>" + eid + "</td>");
				out.println("<td><b>Emp Name</b</td> <td>" + name + "</td>");
				out.println("<td><b>Gender</b</td> <td>" + gen + "</td>");
				for(String q:quil)
				{
					out.println("<td><b>Quil</b</td> <td>" + q + "</td>");
				}
				
				out.println("<td><b>Address</b</td> <td>" + add + "</td>");
				out.println("<td><b>Country</b</td> <td>" + country + "</td>");

				out.println("</tr>");
				out.println("</table>");
				
			  
		}
		catch(Exception e)
		{	System.out.println("EXCEPTION : " + e);
		}
		
	}//end of doGet() 

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doGet(request, response);
	}

}
