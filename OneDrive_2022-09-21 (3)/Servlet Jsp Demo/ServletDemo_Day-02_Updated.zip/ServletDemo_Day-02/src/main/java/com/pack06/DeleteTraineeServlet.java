package com.pack06;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DeleteTraineeServlet extends HttpServlet 
{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try( PrintWriter out= response.getWriter() )
		{  
			 	String name = request.getParameter("t1");
	          	Class.forName("oracle.jdbc.OracleDriver");
	            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "oracleuser2", "password");
	            
	                        
	            PreparedStatement pst = con.prepareStatement("delete from Trainees where name = ?");
	            pst.setString(1, name);

	            int status = pst.executeUpdate();
	             if(status>0)
	             {
	                out.println("<h1>Record deleted successfully.</h1>");
	                out.println("<br/>");
	                out.println("<a href='index.html' >  Go back to Home Page     </a>");

	             }
	             else
	             {
	                out.println("<h1>Operation Failed.Retry.</h1>");
	             }
		}
		catch(Exception e)
		{	System.out.println("EXCEPTION : " + e);
		}
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
