package com.pack08;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class InitParamDemoServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		 	PrintWriter out = response.getWriter();
	        try 
	        {
	           String str = getInitParameter("contactus");
	           out.println("<h1>Contact Us at : "+ str);
	           
	           ServletContext ctxt = getServletContext();
	           String str2 = ctxt.getInitParameter("quote");          
	           out.println("<br>Quote : "+str2);
	       } 
	       finally 
	       { 
	            out.close();
	       }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
