package com.pack04;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CalculatorServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try( PrintWriter out= response.getWriter() )
		{  
			int num1 = Integer.parseInt(request.getParameter("t1"));
			int num2 = Integer.parseInt(request.getParameter("t2"));
			String operation = request.getParameter("t3");
			
			int res = 0;
			out.println("<font size='7' color='red' >");
			
			if(operation.equals("add"))
			{	res =	num1  + num2 ;				    
				out.println("Addition Result from Server = " + res);
			}
			else if(operation.equals("mul"))
			{	res =	num1  * num2 ;	
				out.println("Multiplication Result from Server = " + res);
			}	
			out.println("</font>");
		}
		catch(Exception e)
		{
			System.out.println("EXCEPTION : " + e);
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
