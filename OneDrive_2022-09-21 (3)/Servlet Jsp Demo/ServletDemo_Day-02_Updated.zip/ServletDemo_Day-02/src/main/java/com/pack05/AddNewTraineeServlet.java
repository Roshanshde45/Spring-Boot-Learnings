package com.pack05;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
create table Trainees
(
		name varchar2(50),
		phone varchar2(50)
);

select * from Trainees;
*/
public class AddNewTraineeServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		PrintWriter out= response.getWriter();
		try
		{  
			    String name = request.getParameter("t1");
	            String ph   = request.getParameter("t2");            
	           
	            Class.forName("oracle.jdbc.OracleDriver");
	            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "oracleuser2", "password");
	            
	                        
	            PreparedStatement pst = con.prepareStatement("insert into Trainees values(?,?)");
	            pst.setString(1, name);
	            pst.setString(2, ph);
	            int status = pst.executeUpdate();
	             if(status>0)
	             {
	                out.println("<h1>Record saved successfully.</h1>");
	                out.println("<br/>");
	                out.println("<a href='index.html' >  Go back to Trainees Home Page     </a>");
	             }
	             else
	             {
	                out.println("<h1>Operation Failed.Retry.</h1>");
	             }
		}
		catch(Exception e)
		{
			System.out.println("EXCEPTION : " + e);
			out.println("Some technical error ouccourd. Retry later.");
		}
		finally
		{	out.close();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
