package com.pack03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;

public class ValidateEmployee extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try( PrintWriter out= response.getWriter() )
		{  						
			String name=request.getParameter("user");
			String pwd=request.getParameter("pwd");
			
			RequestDispatcher rd = null;
			
			if(name.equalsIgnoreCase("Jeet") && pwd.equals("admin123"))
			{
				request.setAttribute("unm", name);
				request.setAttribute("unm2", pwd);
				//request.setAttribute("unm3", pwd2);
				
				HttpSession s = request.getSession();			
				s.setAttribute("XYZ", name);
				s.setAttribute("user2", name);
				
				rd= request.getRequestDispatcher("WelcomeServlet");
			    rd.forward(request,response);   //It maintains the session
						
			}
			else
			{	response.sendRedirect("emplogin.jsp");  //It send the fresh new request to the page
			}
		}//end of try
		catch(Exception e)
		{
			System.out.println("EXCEPTION : " + e);
		}
	}//end of doGet()

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
