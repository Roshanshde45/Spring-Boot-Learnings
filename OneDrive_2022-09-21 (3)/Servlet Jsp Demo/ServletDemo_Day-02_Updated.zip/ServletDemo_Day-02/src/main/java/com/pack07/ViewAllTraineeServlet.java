package com.pack07;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ViewAllTraineeServlet extends HttpServlet 
{	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try( PrintWriter out= response.getWriter() )
		{  
			Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "oracleuser2", "password");
            
                        
            Statement st = con.createStatement();
            
            ResultSet rs = st.executeQuery("select * from Trainees order by name asc");
            int count=0;
            
            out.println("<table align='center' border='1'  bgcolor='#ffccff' >");
            out.println("<tr> <td>NAME</td> <td>PHONE</td> </tr>");
            while(rs != null && rs.next())
            {   ++count;
            	out.println("<tr>");   
            	out.println("<td>" + rs.getString("NAME")  + "</td>");
            	out.println("<td>" + rs.getString("PHONE")  + "</td>");
            	out.println("</tr>");
            }
            out.println("<tr> <td colspan=2>Total Records Found = " +  count  +  " </td>  </tr>");
            out.println("</table>");
            
            out.println("<a href='index.html' >  Go back to Trainees Home Page     </a>");
		}
		catch(Exception e)
		{	System.out.println("EXCEPTION : " + e);
		}
	}//end of doGet();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	doGet(request, response);
	}

}
