package com.web.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.spring.model.Employee;

@Controller
@RequestMapping("form")
public class EmployeeFormController 
{

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public ModelAndView employee() 
	{ 	
		return new ModelAndView("emp", "command",  new Employee() );   //WEB-INF/views/emp.jsp
	}
	
		
	
	@RequestMapping(value = "/addemp")
	public ModelAndView createEmployee(Employee emp, ModelAndView model) 
	{ 	model.addObject("xeid", emp.geteId());
		model.addObject("xname", emp.getName());
		model.addObject("xdept", emp.getDept());
		model.setViewName("empinfo");
		return model;
	}

	@RequestMapping(value = "/addemp1")
	public ModelAndView addEmployee(@ModelAttribute(value = "emp") Employee emp, ModelAndView model) 
	{ 	model.addObject("emp");
		model.setViewName("empinfo1");
		return model;
	}


	
}
