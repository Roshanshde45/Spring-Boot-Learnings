package com.web.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.web.spring.model.Employee;


@Controller
@RequestMapping("emp")
public class EmployeeController 
{

	@RequestMapping(value = "/greet")
	public ModelAndView hello() 
	{ 			
		return new ModelAndView("greeting", "msg", "Welcome to Spring MVC.");
	}

	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addEmployee(@RequestParam int id, 
									@RequestParam String name, 
									@RequestParam String dept,
									ModelAndView model) 
	{
		Employee emp = new Employee(id, name, dept);
		
		model.addObject("xeid", id);
		model.addObject("xname", name);
		model.addObject("xdept", dept);
		
		model.setViewName("empinfo");
		return model;
	}
	
	
	
	
}




/*
		/*Employee emp = new Employee(id, name, dept);
		model.addObject("eid", emp.geteId());
		model.addObject("name", emp.getName());
		model.addObject("dept", emp.getDept());
		model.setViewName("empinfo");
		return model;		
*/
