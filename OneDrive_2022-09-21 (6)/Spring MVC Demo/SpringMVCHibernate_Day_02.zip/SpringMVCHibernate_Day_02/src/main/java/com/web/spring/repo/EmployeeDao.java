package com.web.spring.repo;

import java.util.List;
import com.web.spring.model.Employee;

public interface EmployeeDao 
{
	public void addEmployee(Employee emp);
	public List<Employee> listEmp();
}
