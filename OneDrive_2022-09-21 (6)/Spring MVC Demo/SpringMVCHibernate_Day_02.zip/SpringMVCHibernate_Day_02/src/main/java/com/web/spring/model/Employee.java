package com.web.spring.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Empinfo")
public class Employee 
{
	@Id
	@GeneratedValue
    @Column(name="empid")
	private Integer eId;
	
	@Column(name="empname")
	private String name;
	
	@Column(name="Department")
	private String dept;
	
	public Integer geteId() 
	{ 	return eId;
	}
	public void seteId(Integer eId) 
	{ 	this.eId = eId;
	}
	public String getName() 
	{ 	return name;
	}
	public void setName(String name) 
	{ 	this.name = name;
	}
	public String getDept() 
	{ 	return dept;
	}
	public void setDept(String dept) 
	{ 	this.dept = dept;
	}
}
