package com.web.spring.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.web.spring.model.Employee;
import com.web.spring.repo.EmployeeDao;


@Controller
//@RequestMapping("/index")
@RequestMapping("/")
public class EmployeeController 
{
	@Autowired
	private EmployeeDao employeeDao;

	/* @RequestMapping(value="/ind" ,method=RequestMethod.GET) */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView welcome() 
	{ 	return new ModelAndView("index");    //= /WEB-INF/views/index.jsp
	}

	@RequestMapping(value = "add", method = RequestMethod.GET)
	public ModelAndView addEmp() 
	{ 	return new ModelAndView("addEmployee", "emp", new Employee());  // === /WEB-INF/views/addEmployee.jsp
	}

	@RequestMapping(value = "save", method = RequestMethod.POST)
	public ModelAndView saveEmp(Employee emp) 
	{ 	employeeDao.addEmployee(emp);
		return new ModelAndView("redirect:/employees");
		// return new ModelAndView("redirect:/index/employees");
	}

	@RequestMapping(value = "employees", method = RequestMethod.GET)
	public ModelAndView listEmp() 
	{ 	ModelAndView model = new ModelAndView();
		model.addObject("employees", employeeDao.listEmp());
		model.setViewName("emplist");   //=== /WEB-INF/views/emplist.jsp
		return model;
	}
}
