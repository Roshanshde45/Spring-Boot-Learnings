package com.web.spring.repo;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.web.spring.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao 
{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void addEmployee(Employee emp) 
	{ 	Session s = sessionFactory.openSession();
		Transaction tx = s.beginTransaction();
		s.save(emp);
		tx.commit();
		s.close();
	}

	@Override
	public List<Employee> listEmp() 
	{ 	Session s = sessionFactory.openSession();
		List<Employee> elsit = s.createCriteria(Employee.class).list();
		s.close();
		return elsit;
	}

}
