package com.web.spring.controller;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.web.spring.model.User;

@Controller
@RequestMapping("usercontroller")
public class UserController 
{
	@RequestMapping(value="/user" , method=RequestMethod.GET)
	public ModelAndView  user()
	{
		return new ModelAndView("user","user",new User());
	}
	
	@RequestMapping(value="/createUser" , method=RequestMethod.POST)
	public ModelAndView  createUser(@Valid User user, BindingResult res, ModelMap model)
	{ 	if(res.hasErrors())	
		{ 	return new ModelAndView("user");
		}
		else
		{ 	model.addAttribute("name", user.getName());
			model.addAttribute("age", user.getAge());
		  return new ModelAndView("success");
		}	
	}
}
