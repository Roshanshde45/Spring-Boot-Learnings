package com.web.spring.model;

public class Employee 
{
	int    eId;
	String name;
	String dept;
	
	public Employee(int eId, String name, String dept) {
		super();
		this.eId = eId;
		this.name = name;
		this.dept = dept;
	}
	
	public Employee() {
		super();
	}

	
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}

	
	
}//end of class Employee
