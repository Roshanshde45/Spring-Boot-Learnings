package com.web.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.spring.model.Employee;

@Controller
@RequestMapping("form")
public class EmployeeFormController 
{

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public ModelAndView employee() 
	{ 	
		return new ModelAndView("emp", "command",  new Employee() );   //emp-----> WEB-INF/views/emp.jsp
	}
	
		
	
	@RequestMapping(value = "/addemp")
	public ModelAndView createEmployee(Employee emp, ModelAndView model) 
	{ 	model.addObject("xeid", emp.geteId());
		model.addObject("xname", emp.getName());
		model.addObject("xdept", emp.getDept());
		model.setViewName("empinfo");          //empinfo------------> WEB-INF/views/empinfo.jsp
		return model;
	}

	@RequestMapping(value = "/addemp1")
	public ModelAndView addEmployee(@ModelAttribute(value = "emp") Employee emp, ModelAndView model) 
	{ 	model.addObject("emp");
		model.setViewName("empinfo1");
		return model;
	}

	@RequestMapping(value = "getemps", method = RequestMethod.GET)
	public ModelAndView listEmp() 
	{ 	List<Employee> emps = getListOfUsers();

		ModelAndView model = new ModelAndView();
		model.addObject("employees", emps);
		model.setViewName("emplist");       //emplist------------> WEB-INF/views/emplist.jsp
		return model;
	}

	// Dummy method for adding List of Users private List<Employee>
	private List<Employee> getListOfUsers() 
	{ 	List<Employee> users = new ArrayList<>();
		users.add(new Employee(101, "Ravic", "HR"));
		users.add(new Employee(102, "Mohit", "IT"));
		users.add(new Employee(103, "Jeetendra", "Mohit"));
		return users;
	}
	
}
