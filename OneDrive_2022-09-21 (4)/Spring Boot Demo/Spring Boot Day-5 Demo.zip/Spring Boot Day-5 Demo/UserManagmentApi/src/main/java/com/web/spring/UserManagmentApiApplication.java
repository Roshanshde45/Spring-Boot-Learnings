package com.web.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;

@SpringBootApplication
@OpenAPIDefinition(info=@Info(title="User API",version="v1",contact=@Contact(name="Saurabh",email="admin@userapi.com")))
public class UserManagmentApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagmentApiApplication.class, args);
		System.out.println("User Managment API is Running..");
	}

}

