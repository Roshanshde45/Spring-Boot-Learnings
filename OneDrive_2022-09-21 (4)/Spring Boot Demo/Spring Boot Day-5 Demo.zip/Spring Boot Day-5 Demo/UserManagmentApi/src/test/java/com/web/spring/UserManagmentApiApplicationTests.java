package com.web.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagmentApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
//spring Boot 2.6.2 spring frame work v 5.3.14