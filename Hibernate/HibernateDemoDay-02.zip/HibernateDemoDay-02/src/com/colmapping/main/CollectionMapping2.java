package com.colmapping.main;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.colmapping.model.Employee_Info;
import com.persistence.HibernateUtil;

public class CollectionMapping2 
{
	public static void main(String[] args) 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		//Transaction tx= s.beginTransaction();  //Not required for Read Operation

		System.out.println("Printing  the object");
		Employee_Info emp= (Employee_Info) s.get(Employee_Info.class,155);
		Set<String> techlist=emp.getSkills();
		
		
		System.out.println("Empi ID : " + emp.getEmpid() +
				         "\nEmpName : " + emp.getName()  ) ;
		
		System.out.println("Skills ");
		
		Iterator<String> itr =techlist.iterator();
		while(itr.hasNext())
		{	System.out.println("--->"+ itr.next()+" ");
		}
		//tx.commit();
		s.close();
		
	}
}
