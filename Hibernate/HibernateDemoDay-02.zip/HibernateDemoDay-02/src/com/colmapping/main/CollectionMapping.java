package com.colmapping.main;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.colmapping.model.Employee_Info;
import com.persistence.HibernateUtil;

public class CollectionMapping 
{
	public static void main(String[] args) 
	{
		Employee_Info emp1=new Employee_Info();
		
		emp1.setName("Priti");   //Second variable
		
		Set<String> empSkills1 = new HashSet<>();
					empSkills1.add("Java");
					empSkills1.add("Servlet");
					empSkills1.add("Hibernate");		
		
		emp1.setSkills(empSkills1);  //Third Variable
		
		
		
		
		Employee_Info emp2=new Employee_Info();
		emp2.setName("Jeetendra");
		
		Set<String> empSkilss2 = new HashSet<>();
					empSkilss2.add("Spring");
					empSkilss2.add("PHP");
					empSkilss2.add("Struts");		
		
		emp2.setSkills(empSkilss2);
			

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		Transaction tx= s.beginTransaction();
 
		s.save(emp1);
		s.save(emp2);
		
		tx.commit();
		s.close();
		System.out.println("Employee Object with collection of skills Saved in Emp_Info & Emp_skills table.");

	}//end of main()
}


/*
for HiberateDay-2 Demo
---------------------
drop table EMP_ADD;
drop table EMP_SKILLS;
drop table EMP_INFO;
drop table V1_COUNTRY;
drop table V1_HEADOFCOUNTRY;
drop table V2_STATE;
drop table V2_HEADOFSTATE;
drop table V3_BATCH;
drop table V3_TRAINER;
drop table V4_EMPLOYEE_V4_PREVILEDGE;
drop table V4_EMPLOYEE;
drop table V4_PREVILEDGE;

----------------------------------------------------------------------



1) com.colmapping.main
   CollectionMapping---->2)Employee_Info(com.colmapping.model)
   CollectionMapping2
   drop table EMP_SKILLS;
   drop table EMP_INFO;

2) com.onetoonepkfk
    OneToOneMain ------>12)Country  & 13)HeadOfState
    14)LoadObject
    drop table v1_country;
    drop table v1_headofcountry; 

3) com.onetoonepkfkbidrctional
    OneToOneMain ------>16)Country  & 17)HeadOfState
    18)LoadObject
    drop table V2_STATE;
    drop table V2_HEADOFSTATE

4) com.onetomanypkfk
    OneToMantyMain------> 9)Batch    & 11)Trainer

5) com.manytomanybidirctional.jointable
   ManyToManyJoinTable-> 6)Employee & 8)Previledge
    
6) com.componentmapping
   ComponentMapping--->  5)Address  & 3)Emp
   drop table EMP_ADD;   
   
   
for HiberateDay-3 Demo   
----------------------
drop table V5_Info_Data;
drop table V6_INFO_EMPLOYEE;
drop table V6_INFO_STUDENT;
drop table V6_INFO_PERSON;
drop table V7_INFO_EMPLOYEE;
drop table V7_INFO_STUDENT;
drop table V7_INFO_PERSON;
drop table V8_EMPLOYEE;
drop table V8_ADDRESS;

Sequence of HibernateDay-3 Demo
1) com.inheritance.singletableperclasshierarchy
   drop table V5_Info_Data;


2) com.inheritance.tableperclass
   drop table V6_INFO_EMPLOYEE;
   drop table V6_INFO_STUDENT;
   drop table V6_INFO_PERSON;

3) com.inheritance.tablepersubclassjoined
   drop table V7_INFO_EMPLOYEE;
   drop table V7_INFO_STUDENT;
   drop table V7_INFO_PERSON;


4) com.hql
   drop table V8_EMPLOYEE;
   drop table V8_ADDRESS;
    1) TestData  (to load the data in V8* tables
	2) HqlMainApp
	3) HCQLMainApp
	4) NamedQueryExample
   
   
*/
