package com.onetoonepkfk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.persistence.HibernateUtil;

public class OneToOneMain 
{
	public static void main(String[] args) 
	{
		Country country=new Country();
		country.setName("India");
		
		HeadOfCountry hoc=new HeadOfCountry();
		hoc.setName("Narendra Modi");
		hoc.setTitle("Prime Minister");

		country.setHoc(hoc);
		
		
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		Transaction tx= s.beginTransaction();
		s.save(country);
		tx.commit();
		s.close();
		
		System.out.println("\n");
		System.out.println("Country & HeadOfCountry Objects Saved successfully...");
		System.out.println("Country Object saved in Table       : v1_country");
		System.out.println("HeadOfCountry Object saved in Table : v1_headofcountry");

	}//end of main()
}
