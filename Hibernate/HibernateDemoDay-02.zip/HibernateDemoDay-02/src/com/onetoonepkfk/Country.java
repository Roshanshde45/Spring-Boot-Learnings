package com.onetoonepkfk;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "V1_COUNTRY")
public class Country 
{
	@Id 
	@GeneratedValue
	int id;
	
	String name;	
	
	@OneToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="hocid")	        //This will be the foreign key in COUNTRY Table	
	HeadOfCountry hoc;

	
	public int getId() 
	{	return id;
	}
	public void setId(int id) 
	{	this.id = id;
	}
	public String getName() 
	{	return name;
	}
	public void setName(String name) 
	{	this.name = name;
	}
	public HeadOfCountry getHoc() 
	{	return hoc;
	}
	public void setHoc(HeadOfCountry hoc) 
	{	this.hoc = hoc;
	}
}
