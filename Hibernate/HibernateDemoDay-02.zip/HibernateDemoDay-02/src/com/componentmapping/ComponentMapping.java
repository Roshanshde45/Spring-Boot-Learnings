package com.componentmapping;

import org.hibernate.Session;
import org.hibernate.Transaction;
//import org.hibernate.classic.Session;

import com.persistence.HibernateUtil;

public class ComponentMapping 
{

	public static void main(String[] args) 
	{
		Address add = new Address("Noida", "UP");
		
		Emp e=new Emp( "Jeetendra", add );
		
		
		Session s= HibernateUtil.getSessionFactory().openSession();		
		Transaction tx= s.beginTransaction();
		s.save(e);
		System.out.println("Object Saved...");
		tx.commit();
		s.close();
		
	}

}
