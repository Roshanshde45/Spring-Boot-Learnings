package com.onetoonepkfkbidrctional;

import javax.persistence.Entity;
import javax.persistence.*;

@Entity
@Table(name="V2_STATE")
public class State 
{
	@Id 
	@GeneratedValue
	@Column(name="STATE_ID")
	int id;
	
	String name;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="hos_id")       //It will generate foreign key
	HeadOfState hos;
	
	public int getId() 
	{	return id;
	}
	public void setId(int id) 
	{	this.id = id;
	}
	public String getName() 
	{	return name;
	}
	public void setName(String name) 
	{	this.name = name;
	}
	public HeadOfState getHos() 
	{	return hos;
	}
	public void setHos(HeadOfState hos) 
	{	this.hos = hos;
	}
}
