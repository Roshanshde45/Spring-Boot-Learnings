package com.onetoonepkfkbidrctional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.persistence.HibernateUtil;
public class LoadObject 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		
        HeadOfState hos1= (HeadOfState) s.load(HeadOfState.class, 15);
        State state1 = hos1.getState();
        System.out.println("\nStatename  : " +  state1.getName() +
    		   			   "\nState Head : " +  hos1.getName()   +
    		   			   "\nTitle      : " +  hos1.getTitle()  );
        
        
        System.out.println("\n\n*******************************************\n\n");
        
        State state2= (State) s.load(State.class, 14);
        
        HeadOfState hos2= state2.getHos();  
        System.out.println("\nStatename  : " +  state2.getName() +
    		   			   "\nState Head : " +  hos2.getName()   +
    		   			   "\nTitle      : " +  hos2.getTitle()  );
        
	}//end of main()
	
}//end of class LoadObject
