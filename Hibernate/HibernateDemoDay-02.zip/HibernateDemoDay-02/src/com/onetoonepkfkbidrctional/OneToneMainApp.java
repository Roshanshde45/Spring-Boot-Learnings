package com.onetoonepkfkbidrctional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.onetoonepkfkbidrctional.State;
import com.onetoonepkfkbidrctional.HeadOfState;
import com.persistence.HibernateUtil;


public class OneToneMainApp 
{
	public static void main(String[] args) 
	{
		State state=new State();
		state.setName("Gujarat");
		
		HeadOfState hos=new HeadOfState();
		hos.setName("Narendra Modi");
		hos.setTitle("Chief Minister");
		//hos.setState(state);
		
		state.setHos(hos);
		
		
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		Transaction tx= s.beginTransaction();
		s.save(state);
		tx.commit();
		s.close();	  
		
		System.out.println("\n\nState & HeadOfState Objects Saved successfully...");
		System.out.println("State Object saved in Table : V2_STATE");
		System.out.println("HeadOfState Object saved in Table : V2_HEADOFSTATE");
	}
}
