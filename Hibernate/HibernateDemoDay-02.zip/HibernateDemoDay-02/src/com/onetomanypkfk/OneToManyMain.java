package com.onetomanypkfk;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.persistence.HibernateUtil;

public class OneToManyMain 
{
	public static void main(String[] args) 
	{
		Trainer t1=new Trainer();
		t1.setName("Jeetendra");

		Trainer t2=new Trainer();
		t2.setName("Priti");
		
		
		
		Batch b1=new Batch("8 to 10", "w/e");
		Batch b2=new Batch("10 to 12", "w/e");
		
		Batch b3=new Batch("3 to 5", "w/d");
		Batch b4=new Batch("5 to 7", "w/d");
		
		
		
		Set<Batch> batch1=new HashSet<>();
		batch1.add(b1);
		batch1.add(b2);
		

		Set<Batch> batch2=new HashSet<>();
		batch2.add(b3);
		batch2.add(b4);
		
		t1.setBatches(batch1);
		t2.setBatches(batch2);
		
		
		
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s=sf.openSession();		
		Transaction tx= s.beginTransaction();			
		s.save(t1);
		s.save(t2);				
		tx.commit();
		s.close();		
		
		
		
		System.out.println("\n");
		System.out.println("Trainer & Batch Objects Saved successfully...");
		System.out.println("Trainer Object saved in Table : V3_TRAINER");
		System.out.println("Batch Object saved in Table   : V3_BATCH");

		
	}
}
