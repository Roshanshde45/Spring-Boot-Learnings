package com.manytomanybidirctional.jointable;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.persistence.HibernateUtil;

public class ManyToManyJoinTable 
{

	public static void main(String[] args)
	{				
		Previledge p1=new Previledge();
		p1.setName("Car");
		p1.setCost(200000);
		
		
		Previledge p2=new Previledge();
		p2.setName("Trip");
		p2.setCost(100000);
		
		
		Previledge p3=new Previledge();
		p3.setName("Flat");
		p3.setCost(200000);
		
		
		Employee emp1=new Employee("James", "CEO",      1000000);
		Employee emp2=new Employee("John",  "Director", 1000000);
				
		Set<Previledge> set1=new HashSet<>();   //Car , Trip, Flat
		Set<Previledge> set2=new HashSet<>();   //Car , Trip
		
		set1.add(p1);
		set1.add(p2);
		set1.add(p3);
		
		set2.add(p1);
		set2.add(p2);
		
		emp1.setPreviledge(set1);     //Car , Trip, Flat
		emp2.setPreviledge(set2);     //Car , Trip
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		Transaction tx= s.beginTransaction();		
		s.save(emp1);
		s.save(emp2);		
		tx.commit();
		s.close();
		
		System.out.println("\n");
		System.out.println("Employee & Previledge Objects Saved successfully...");
		System.out.println("Employee Object saved in Table   : V4_EMPLOYEE");
		System.out.println("Previledge Object saved in Table : V4_PREVILEDGE");
	
	}//end of main()
}
