package com.inheritance.tablepersubclassjoined;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="V7_INFO_EMPLOYEE")
@PrimaryKeyJoinColumn
public class Employee extends Person 
{
	String desg;
	long sal;
	
	public Employee(String name, String desg, long sal) 
	{ 	super(name);
		this.desg = desg;
		this.sal = sal;
	}
	public Employee() 
	{ 
	}
	public String getDesg() 
	{ 	return desg;
	}
	public void setDesg(String desg) 
	{ 	this.desg = desg;
	}
	public long getSal() 
	{ 	return sal;
	}
	public void setSal(long sal) 
	{ 	this.sal = sal;
	}
}
