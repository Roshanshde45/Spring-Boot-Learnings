package com.inheritance.tablepersubclassjoined;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.persistence.HibernateUtil;

public class PersistEmployeeMain 
{
	public static void main(String[] args) 
	{
		Person p=new Person("Alisha");
		Employee emp = new Employee("Priti", "SE",    50000L);
		Student std  = new Student("Jeet", "Java", 30000 );
		
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();		
		Transaction tx=s.beginTransaction();
			s.save(p);
			s.save(emp);
			s.save(std);
		tx.commit();
		s.close();	
		System.out.println("Object Savedd..");
	}
}
