package com.jeet;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


@WebServlet(name = "MainServlet11", urlPatterns ={    "/MainServlet11"  })
public class MainServlet11 extends HttpServlet
{


    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter())
        {
            out.println("<br><br><br><br><br>");
            out.print("Request processing started.....");
            out.println("<br><br><br><br><br>");
           

            StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
            Metadata metaData = new MetadataSources(standardRegistry).getMetadataBuilder().build();
            SessionFactory sessionFactory = metaData.getSessionFactoryBuilder().build();  //resource intensive
            Session session = sessionFactory.openSession();
            session.beginTransaction();

            
            //---------------------------
            Event party1 = new Event(); 
            party1.setEventName("Birthday Party");
            
            Event party2 = new Event(); 
            party2.setEventName("Wedding Party");            
            //-----------------------------  
            
            
            Delegate d1 = new Delegate();  
            d1.setDelegateName("Jeet");
            
            Delegate d2 = new Delegate();  
            d2.setDelegateName("Jatin");
            //-----------------------------
            
            party1.getDelegates().add(d1);
            party1.getDelegates().add(d2);
            
            
            party2.getDelegates().add(d1);
            party2.getDelegates().add(d2);            
            //------------------------------
            d1.getEvents().add(party1);
            d1.getEvents().add(party2);
            
            d2.getEvents().add(party1);
            d2.getEvents().add(party2);
               
            session.save(party1);       //does not insert the record in database 
            session.save(party2);            
            
            session.save(d1);
            session.save(d2);            
   
            
            session.getTransaction().commit();
            out.println("MainServlet11: Record saved with Many to Many Mapping.");
            
        }
        catch (Exception e)
        {    System.out.println("\n\n\n\nException in JeetServlet :\n\n" + e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

}
