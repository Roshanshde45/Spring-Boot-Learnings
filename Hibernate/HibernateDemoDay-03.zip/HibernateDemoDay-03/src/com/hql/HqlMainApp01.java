package com.hql;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.persistence.HibernateUtil;


public class HqlMainApp01 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();		
		
		System.out.println("query1: Reading All Entities from table\n");
		//Transaction tx= s.beginTransaction();	
		Query query1= s.createQuery("from Employee");
		
		List<Employee> elist= (List<Employee>) query1.list();
		
		for(Employee emp:elist)
		{	System.out.println("\nEid  : " + emp.getId()	 +
							   "\nName : " + emp.getName() +
							   "\nCity : " + emp.getAddress().getCity());			
		}		
		
		s.close();
		
	}//end of main()

}
