package com.hql;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.persistence.HibernateUtil;


public class HqlMainApp03 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();		
		
		System.out.println("\n\nquery3: Get Employee with id using named Parameter Binding");	
		Query query3=s.createQuery("from Employee where id= :id");
		query3.setLong("id", 173);	
		
		Employee emp= (Employee)query3.uniqueResult();
		System.out.println("\n\nEid  : " + emp.getId()	 +
						   "\nName : "   + emp.getName() +
						   "\nCity : "   + emp.getAddress().getCity());
		
	
		s.close();
		
	}//end of main()

}
