package com.hql;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.persistence.HibernateUtil;


public class HqlMainApp04 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();		
		
		System.out.println("\n\nquery4: Get Employee with id using Postional Parameter Binding");		
		Query query4=s.createQuery("from Employee where id= ?");
		query4.setLong(0, 173);	
		Employee emp = (Employee)query4.uniqueResult();
		System.out.println("\n\nEid  : " + emp.getId()	 +
						   "\nName : "   + emp.getName() +
						   "\nCity : "   + emp.getAddress().getCity());		
		s.close();
	}//end of main()

}
