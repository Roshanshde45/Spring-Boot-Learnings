package com.hql;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.persistence.HibernateUtil;


public class HqlMainApp07 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();
		
		System.out.println("\n\nquery7: Sum Salary of Employee");
	  //Query query7 = s.createQuery("select sum(e.salary ) from Employee e");	
		Query query7 = s.createQuery("select sum(  salary ) from Employee ");
		double sumSal= (double) query7.uniqueResult();	
		System.out.println("Total Sal : "+sumSal);
		

		
		System.out.println("\n\nquery8: AVG Salary of Employee");
		Query query8 = s.createQuery("select avg( salary ) from Employee ");
		double avgSal= (double) query8.uniqueResult();	
		System.out.println("AVG Sal : "+avgSal);
		
		
		System.out.println("\n\nquery9: Total no of Employee");
		Query query9=s.createQuery("select count( * ) from Employee ");
		long noOfEmployees= (Long) query9.uniqueResult();	
		System.out.println("Total No of Employees : "+noOfEmployees);	
	
		s.close();
	}//end of main()

}
