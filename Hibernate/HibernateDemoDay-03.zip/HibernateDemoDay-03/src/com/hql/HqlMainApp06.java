package com.hql;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.persistence.HibernateUtil;


public class HqlMainApp06 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();				
		Transaction tx= s.beginTransaction();	
		
	    System.out.println("\n\nquery6: Delete Employee");		
		Query query6=s.createQuery("delete Employee  where id= :id ");
		query6.setLong("id", 173L);
		int res2= query6.executeUpdate();
		System.out.println("No of row deleted : "+res2);
		tx.commit();
		
		s.close();
		
	}//end of main()
}
