package com.hql;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.persistence.HibernateUtil;



public class NamedQueryExample 
{

	public static void main(String[] args) 
	{

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		//Transaction tx = session.beginTransaction();

		
		System.out.println("\n\nGet All Employee  \n");
		
		Query query = session.getNamedQuery("get_all_emp");
		List<Employee> elist = query.list();
		for (Employee emp : elist) 
		{	System.out.println("\nEid  : " + emp.getId()	 +
							   "\nName : " + emp.getName() +
							   "\nCity : " + emp.getAddress().getCity());		
		}//end of for loop
		
		
		
		
		
		System.out.println("\n\nTotal Employee Count \n");
		query = session.getNamedQuery("get_total_emp");
		Long empCount = (Long) query.uniqueResult();
		System.out.println("Total Emp Count is " + empCount);		
		
		
		
		System.out.println("\n\nGet Employee By Id  \n");
		query = session.getNamedQuery("get_emp_byid");
		query.setInteger("id", 175);
		Employee emp = (Employee) query.uniqueResult();
		System.out.println("\nEid  : " + emp.getId()   +
						   "\nName : " + emp.getName() +
						   "\nCity : " + emp.getAddress().getCity());		

 
		//tx.commit();
	    session.close();
	}//end of main

}
