package com.hql;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.persistence.HibernateUtil;


public class HqlMainApp02 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();		
		
		System.out.println("\n\nquery2: Reading Partial Entity\n");	
		Query query2=s.createQuery("select e.id, e.name, e.salary, e.address.city from Employee e");
		List emplist1= query2.list();		
		Iterator it= emplist1.iterator();
		
		while (it.hasNext()) 
		{	Object []arr= (Object[]) it.next();
			System.out.println("\nEid   : " + arr[0] +
							   "\nName  : " + arr[1] +
							   "\nSalary: " + arr[2] +
							   "\nCity  : " + arr[3] ) ;			
		}//end of while loop		
	
		s.close();
	}//end of main()

}
