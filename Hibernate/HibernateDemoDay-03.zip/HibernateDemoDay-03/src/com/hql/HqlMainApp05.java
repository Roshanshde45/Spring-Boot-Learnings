package com.hql;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.persistence.HibernateUtil;


public class HqlMainApp05 
{
	public static void main(String[] args) 
	{
		SessionFactory sf= HibernateUtil.getSessionFactory();
		Session s= sf.openSession();		
		Transaction tx= s.beginTransaction();
		
		System.out.println("\n\nUpdate Employee");		
		Query query5=s.createQuery("update Employee set name=:name where id= :id");
		query5.setString("name","Alice");
		query5.setLong("id", 175);
		int res1= query5.executeUpdate();
		tx.commit();
		
		
		System.out.println("No of rows Updated "+res1);
		s.close();
	}//end of main()

}
