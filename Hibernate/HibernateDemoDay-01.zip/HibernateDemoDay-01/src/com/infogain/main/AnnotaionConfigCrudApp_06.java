package com.infogain.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infogain.model.Customer;
import com.infogain.persistence.HibernateUtil;

public class AnnotaionConfigCrudApp_06 
{

	public static void main(String[] args) 
	{
		
		//Getting Object of SeseeionFactory using AnnotationConfiguration class
				//SessionFactory sf= new AnnotationConfiguration().configure().buildSessionFactory();

				SessionFactory sf = HibernateUtil.getSessionFactory();
				Session session = sf.openSession();		

				//-------------------Example-06---------------------------
				Transaction tx = session.beginTransaction();
				Customer cust = (Customer) session.get(Customer.class, 1);
				session.delete(cust);
				tx.commit();
				System.out.println("Record Deleted Successfully..."); 		
				session.close(); // Close session			       	
		
	}//end of main()

}
