package com.infogain.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infogain.model.Customer;
import com.infogain.persistence.HibernateUtil;

public class AnnotaionConfigCrudApp_03 
{

	public static void main(String[] args) 
	{
		
			//  Getting Object of SeseeionFactory using AnnotationConfiguration class
			//SessionFactory sf= new AnnotationConfiguration().configure().buildSessionFactory();

			//-------------------Example-03-------------------		
			
			SessionFactory sf = HibernateUtil.getSessionFactory();
			Session session = sf.openSession();
			
			System.out.println("Loding an entity using get method"); 
			Customer cust3 =(Customer) session.get(Customer.class, 1);
			  
			System.out.println("Cust_Id : " + cust3.getCustomerId() );
			System.out.println("Name    : " + cust3.getCustomerName() );
			System.out.println("Address : " + cust3.getCustomerAddress() );
			 					
			session.close(); // Close session
		
	}//end of main()

}
