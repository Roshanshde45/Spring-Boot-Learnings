package com.infogain.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infogain.model.Customer;
import com.infogain.persistence.HibernateUtil;

public class AnnotaionConfigCrudApp_01 
{

	public static void main(String[] args) 
	{
		
			//  Getting Object of SeseeionFactory using AnnotationConfiguration class
			//SessionFactory sf= new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

			//-------------------Example-01-------------------
			Customer cust1 = new Customer();
			cust1.setCustomerName("Priti");
			cust1.setCustomerAddress("Pune");
					
			SessionFactory sf = HibernateUtil.getSessionFactory();
			Session session = sf.openSession();	
			Transaction tx = session.beginTransaction();
			
			session.save(cust1); //This code will not save the data in database table.
			
			tx.commit(); // Tranasction commited
			session.close(); // Close session
			
			System.out.println("Customer Saved..");	
		
	}//end of main()

}
