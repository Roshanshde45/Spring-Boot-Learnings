package com.infogain.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infogain.model.Customer;
import com.infogain.persistence.HibernateUtil;

public class AnnotaionConfigCrudApp_05 
{

	public static void main(String[] args) 
	{
		
		//Getting Object of SeseeionFactory using AnnotationConfiguration class
		//SessionFactory sf= new AnnotationConfiguration().configure().buildSessionFactory();

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
				
		//-------------------Example-05-------------------
		//Second way of Updating
				
				
		Customer cust5 =new Customer();
		cust5.setCustomerId(1);       // Id must be existing in database table
		cust5.setCustomerName("Guuuullsshan");
		cust5.setCustomerAddress("Delhi");
				
		Transaction tx = session.beginTransaction();		  
		session.update(cust5); 
		tx.commit();
		System.out.println("Record Updated Successfully...");		       	
		
	}//end of main()

}
